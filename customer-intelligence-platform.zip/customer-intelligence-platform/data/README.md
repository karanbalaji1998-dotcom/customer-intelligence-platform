# Data directory

Keep licensed/public raw data under `data/raw/` and derived data under `data/processed/`.
CSV data files are ignored by Git by default; this prevents accidentally committing customer data.

## Expected fields (to be finalized after dataset selection)

- `customer_id`: customer identifier (not a predictor)
- `churn`: target label (definition and observation window must be documented)
- `monthly_revenue`: monthly revenue or an explicitly documented proxy
- `tenure_months`: tenure at the scoring date

The selected public dataset may use different column names. Map them in a controlled preprocessing step.
Never commit real customer data, personal information, confidential business data, credentials, or API keys.
